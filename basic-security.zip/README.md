# Basic security
This plugin lets you check for suspicious IP trying to connect to the admin area, configure blocking IP settings and verify other security settings.